﻿namespace P_Form
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.checkBox10 = new System.Windows.Forms.CheckBox();
            this.checkBox11 = new System.Windows.Forms.CheckBox();
            this.checkBox12 = new System.Windows.Forms.CheckBox();
            this.button1 = new System.Windows.Forms.Button();
            this.checkBox9 = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(224, 62);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(121, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "한달에 여행가는 횟수";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(224, 129);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(133, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "주로 이용하는 이동수단";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(224, 212);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(105, 12);
            this.label3.TabIndex = 1;
            this.label3.Text = "선호하는 여행테마";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.CheckAlign = System.Drawing.ContentAlignment.TopCenter;
            this.checkBox1.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.checkBox1.Location = new System.Drawing.Point(226, 87);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(27, 30);
            this.checkBox1.TabIndex = 2;
            this.checkBox1.Text = "0회";
            this.checkBox1.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.CheckAlign = System.Drawing.ContentAlignment.TopCenter;
            this.checkBox2.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.checkBox2.Location = new System.Drawing.Point(292, 87);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(37, 30);
            this.checkBox2.TabIndex = 2;
            this.checkBox2.Text = "1,2회";
            this.checkBox2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.checkBox2.UseVisualStyleBackColor = true;
            this.checkBox2.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.CheckAlign = System.Drawing.ContentAlignment.TopCenter;
            this.checkBox3.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.checkBox3.Location = new System.Drawing.Point(357, 87);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(37, 30);
            this.checkBox3.TabIndex = 2;
            this.checkBox3.Text = "3,4회";
            this.checkBox3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.checkBox3.UseVisualStyleBackColor = true;
            this.checkBox3.CheckedChanged += new System.EventHandler(this.checkBox3_CheckedChanged);
            // 
            // checkBox4
            // 
            this.checkBox4.CheckAlign = System.Drawing.ContentAlignment.TopCenter;
            this.checkBox4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.checkBox4.Location = new System.Drawing.Point(393, 87);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(68, 30);
            this.checkBox4.TabIndex = 2;
            this.checkBox4.Text = "5회 이상";
            this.checkBox4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.checkBox4.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.checkBox4.UseVisualStyleBackColor = true;
            this.checkBox4.CheckedChanged += new System.EventHandler(this.checkBox4_CheckedChanged);
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.CheckAlign = System.Drawing.ContentAlignment.TopCenter;
            this.checkBox5.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.checkBox5.Location = new System.Drawing.Point(208, 153);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(45, 30);
            this.checkBox5.TabIndex = 2;
            this.checkBox5.Text = "자가용";
            this.checkBox5.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.checkBox5.UseVisualStyleBackColor = true;
            this.checkBox5.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.CheckAlign = System.Drawing.ContentAlignment.TopCenter;
            this.checkBox6.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.checkBox6.Location = new System.Drawing.Point(296, 153);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(33, 30);
            this.checkBox6.TabIndex = 2;
            this.checkBox6.Text = "기차";
            this.checkBox6.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.checkBox6.UseVisualStyleBackColor = true;
            this.checkBox6.CheckedChanged += new System.EventHandler(this.checkBox6_CheckedChanged);
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.CheckAlign = System.Drawing.ContentAlignment.TopCenter;
            this.checkBox7.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.checkBox7.Location = new System.Drawing.Point(348, 153);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(33, 30);
            this.checkBox7.TabIndex = 2;
            this.checkBox7.Text = "버스";
            this.checkBox7.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.checkBox7.UseVisualStyleBackColor = true;
            this.checkBox7.CheckedChanged += new System.EventHandler(this.checkBox7_CheckedChanged);
            // 
            // checkBox8
            // 
            this.checkBox8.CheckAlign = System.Drawing.ContentAlignment.TopCenter;
            this.checkBox8.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.checkBox8.Location = new System.Drawing.Point(406, 153);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(55, 30);
            this.checkBox8.TabIndex = 2;
            this.checkBox8.Text = "비행기";
            this.checkBox8.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.checkBox8.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.checkBox8.UseVisualStyleBackColor = true;
            this.checkBox8.CheckedChanged += new System.EventHandler(this.checkBox8_CheckedChanged);
            // 
            // checkBox10
            // 
            this.checkBox10.CheckAlign = System.Drawing.ContentAlignment.TopCenter;
            this.checkBox10.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.checkBox10.Location = new System.Drawing.Point(271, 237);
            this.checkBox10.Name = "checkBox10";
            this.checkBox10.Size = new System.Drawing.Size(58, 30);
            this.checkBox10.TabIndex = 2;
            this.checkBox10.Text = "숙소위주";
            this.checkBox10.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.checkBox10.UseVisualStyleBackColor = true;
            this.checkBox10.CheckedChanged += new System.EventHandler(this.checkBox10_CheckedChanged);
            // 
            // checkBox11
            // 
            this.checkBox11.AutoSize = true;
            this.checkBox11.CheckAlign = System.Drawing.ContentAlignment.TopCenter;
            this.checkBox11.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.checkBox11.Location = new System.Drawing.Point(337, 237);
            this.checkBox11.Name = "checkBox11";
            this.checkBox11.Size = new System.Drawing.Size(57, 30);
            this.checkBox11.TabIndex = 2;
            this.checkBox11.Text = "단체여행";
            this.checkBox11.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.checkBox11.UseVisualStyleBackColor = true;
            this.checkBox11.CheckedChanged += new System.EventHandler(this.checkBox11_CheckedChanged);
            // 
            // checkBox12
            // 
            this.checkBox12.CheckAlign = System.Drawing.ContentAlignment.TopCenter;
            this.checkBox12.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.checkBox12.Location = new System.Drawing.Point(391, 237);
            this.checkBox12.Name = "checkBox12";
            this.checkBox12.Size = new System.Drawing.Size(70, 30);
            this.checkBox12.TabIndex = 2;
            this.checkBox12.Text = "드라이브";
            this.checkBox12.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.checkBox12.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.checkBox12.UseVisualStyleBackColor = true;
            this.checkBox12.CheckedChanged += new System.EventHandler(this.checkBox12_CheckedChanged);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(604, 397);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 3;
            this.button1.Text = "다음";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // checkBox9
            // 
            this.checkBox9.AutoCheck = false;
            this.checkBox9.CheckAlign = System.Drawing.ContentAlignment.TopCenter;
            this.checkBox9.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.checkBox9.Location = new System.Drawing.Point(196, 237);
            this.checkBox9.Name = "checkBox9";
            this.checkBox9.Size = new System.Drawing.Size(69, 38);
            this.checkBox9.TabIndex = 4;
            this.checkBox9.Text = "맛집탐방";
            this.checkBox9.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.checkBox9.UseVisualStyleBackColor = true;
            this.checkBox9.CheckedChanged += new System.EventHandler(this.checkBox9_CheckedChanged);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.checkBox9);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.checkBox12);
            this.Controls.Add(this.checkBox11);
            this.Controls.Add(this.checkBox8);
            this.Controls.Add(this.checkBox7);
            this.Controls.Add(this.checkBox10);
            this.Controls.Add(this.checkBox4);
            this.Controls.Add(this.checkBox6);
            this.Controls.Add(this.checkBox3);
            this.Controls.Add(this.checkBox5);
            this.Controls.Add(this.checkBox2);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form2";
            this.Text = "Form2";

            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.CheckBox checkBox8;
        private System.Windows.Forms.CheckBox checkBox10;
        private System.Windows.Forms.CheckBox checkBox11;
        private System.Windows.Forms.CheckBox checkBox12;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.CheckBox checkBox9;
    }
}